this archive mixes safe and unsafe entries
